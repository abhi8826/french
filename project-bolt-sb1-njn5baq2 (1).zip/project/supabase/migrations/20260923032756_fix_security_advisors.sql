-- Fix 1: Lock down search_path on touch_updated_at
ALTER FUNCTION public.touch_updated_at() SET search_path = public, pg_temp;

-- Fix 2: Revoke EXECUTE on is_teacher() from anon (not needed for unauthenticated access)
REVOKE EXECUTE ON FUNCTION public.is_teacher() FROM anon;

-- Keep EXECUTE granted to authenticated (RLS policies call it internally)