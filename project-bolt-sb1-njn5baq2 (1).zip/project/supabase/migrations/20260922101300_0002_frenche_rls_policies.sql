/*
# Frenché — Row Level Security Policies

Enables access control on all tables:
- Students see only their own data and published courses they're enrolled in.
- Teachers (role=teacher in app_meta_data) have full CRUD on all content tables.
- Helper: public.is_teacher() checks the immutable JWT app_metadata.role.
*/

-- ─── profiles ───
DROP POLICY IF EXISTS "profiles_select_own_or_teacher" ON public.profiles;
CREATE POLICY "profiles_select_own_or_teacher"
ON public.profiles FOR SELECT TO authenticated
USING (auth.uid() = id OR public.is_teacher());

DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
CREATE POLICY "profiles_insert_own"
ON public.profiles FOR INSERT TO authenticated
WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own"
ON public.profiles FOR UPDATE TO authenticated
USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ─── courses ───
DROP POLICY IF EXISTS "courses_select" ON public.courses;
CREATE POLICY "courses_select"
ON public.courses FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR (
    status = 'published'
    AND EXISTS (
      SELECT 1 FROM public.enrollments e
      WHERE e.course_id = courses.id AND e.student_id = auth.uid()
    )
  )
);

DROP POLICY IF EXISTS "courses_insert_teacher" ON public.courses;
CREATE POLICY "courses_insert_teacher"
ON public.courses FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "courses_update_teacher" ON public.courses;
CREATE POLICY "courses_update_teacher"
ON public.courses FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "courses_delete_teacher" ON public.courses;
CREATE POLICY "courses_delete_teacher"
ON public.courses FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── modules ───
DROP POLICY IF EXISTS "modules_select" ON public.modules;
CREATE POLICY "modules_select"
ON public.modules FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR EXISTS (
    SELECT 1 FROM public.enrollments e
    JOIN public.courses c ON c.id = e.course_id
    WHERE modules.course_id = c.id AND e.student_id = auth.uid() AND c.status = 'published'
  )
);

DROP POLICY IF EXISTS "modules_insert_teacher" ON public.modules;
CREATE POLICY "modules_insert_teacher"
ON public.modules FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "modules_update_teacher" ON public.modules;
CREATE POLICY "modules_update_teacher"
ON public.modules FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "modules_delete_teacher" ON public.modules;
CREATE POLICY "modules_delete_teacher"
ON public.modules FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── lessons ───
DROP POLICY IF EXISTS "lessons_select" ON public.lessons;
CREATE POLICY "lessons_select"
ON public.lessons FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR (
    published = true
    AND EXISTS (
      SELECT 1 FROM public.enrollments e
      JOIN public.courses c ON c.id = e.course_id
      JOIN public.modules m ON m.course_id = c.id
      WHERE lessons.module_id = m.id AND e.student_id = auth.uid() AND c.status = 'published'
    )
  )
);

DROP POLICY IF EXISTS "lessons_insert_teacher" ON public.lessons;
CREATE POLICY "lessons_insert_teacher"
ON public.lessons FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "lessons_update_teacher" ON public.lessons;
CREATE POLICY "lessons_update_teacher"
ON public.lessons FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "lessons_delete_teacher" ON public.lessons;
CREATE POLICY "lessons_delete_teacher"
ON public.lessons FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── resources ───
DROP POLICY IF EXISTS "resources_select" ON public.resources;
CREATE POLICY "resources_select"
ON public.resources FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR EXISTS (
    SELECT 1 FROM public.enrollments e
    JOIN public.courses c ON c.id = e.course_id
    JOIN public.modules m ON m.course_id = c.id
    JOIN public.lessons l ON l.module_id = m.id
    WHERE resources.lesson_id = l.id AND e.student_id = auth.uid() AND c.status = 'published' AND l.published = true
  )
);

DROP POLICY IF EXISTS "resources_insert_teacher" ON public.resources;
CREATE POLICY "resources_insert_teacher"
ON public.resources FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "resources_update_teacher" ON public.resources;
CREATE POLICY "resources_update_teacher"
ON public.resources FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "resources_delete_teacher" ON public.resources;
CREATE POLICY "resources_delete_teacher"
ON public.resources FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── vocab ───
DROP POLICY IF EXISTS "vocab_select" ON public.vocab;
CREATE POLICY "vocab_select"
ON public.vocab FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR EXISTS (
    SELECT 1 FROM public.enrollments e
    JOIN public.courses c ON c.id = e.course_id
    JOIN public.modules m ON m.course_id = c.id
    JOIN public.lessons l ON l.module_id = m.id
    WHERE vocab.lesson_id = l.id AND e.student_id = auth.uid() AND c.status = 'published' AND l.published = true
  )
);

DROP POLICY IF EXISTS "vocab_insert_teacher" ON public.vocab;
CREATE POLICY "vocab_insert_teacher"
ON public.vocab FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "vocab_update_teacher" ON public.vocab;
CREATE POLICY "vocab_update_teacher"
ON public.vocab FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "vocab_delete_teacher" ON public.vocab;
CREATE POLICY "vocab_delete_teacher"
ON public.vocab FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── enrollments ───
DROP POLICY IF EXISTS "enrollments_select" ON public.enrollments;
CREATE POLICY "enrollments_select"
ON public.enrollments FOR SELECT TO authenticated
USING (student_id = auth.uid() OR public.is_teacher());

DROP POLICY IF EXISTS "enrollments_insert_teacher" ON public.enrollments;
CREATE POLICY "enrollments_insert_teacher"
ON public.enrollments FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "enrollments_delete_teacher" ON public.enrollments;
CREATE POLICY "enrollments_delete_teacher"
ON public.enrollments FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── lesson_progress ───
DROP POLICY IF EXISTS "lesson_progress_select" ON public.lesson_progress;
CREATE POLICY "lesson_progress_select"
ON public.lesson_progress FOR SELECT TO authenticated
USING (student_id = auth.uid() OR public.is_teacher());

DROP POLICY IF EXISTS "lesson_progress_upsert_student" ON public.lesson_progress;
CREATE POLICY "lesson_progress_upsert_student"
ON public.lesson_progress FOR INSERT TO authenticated
WITH CHECK (student_id = auth.uid());

DROP POLICY IF EXISTS "lesson_progress_update_student" ON public.lesson_progress;
CREATE POLICY "lesson_progress_update_student"
ON public.lesson_progress FOR UPDATE TO authenticated
USING (student_id = auth.uid()) WITH CHECK (student_id = auth.uid());

DROP POLICY IF EXISTS "lesson_progress_delete_teacher" ON public.lesson_progress;
CREATE POLICY "lesson_progress_delete_teacher"
ON public.lesson_progress FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── quizzes ───
DROP POLICY IF EXISTS "quizzes_select" ON public.quizzes;
CREATE POLICY "quizzes_select"
ON public.quizzes FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR EXISTS (
    SELECT 1 FROM public.enrollments e
    JOIN public.courses c ON c.id = e.course_id
    JOIN public.modules m ON m.course_id = c.id
    JOIN public.lessons l ON l.module_id = m.id
    WHERE quizzes.lesson_id = l.id AND e.student_id = auth.uid() AND c.status = 'published' AND l.published = true
  )
);

DROP POLICY IF EXISTS "quizzes_insert_teacher" ON public.quizzes;
CREATE POLICY "quizzes_insert_teacher"
ON public.quizzes FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "quizzes_update_teacher" ON public.quizzes;
CREATE POLICY "quizzes_update_teacher"
ON public.quizzes FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "quizzes_delete_teacher" ON public.quizzes;
CREATE POLICY "quizzes_delete_teacher"
ON public.quizzes FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── quiz_questions ───
DROP POLICY IF EXISTS "quiz_questions_select" ON public.quiz_questions;
CREATE POLICY "quiz_questions_select"
ON public.quiz_questions FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR EXISTS (
    SELECT 1 FROM public.quizzes q
    JOIN public.lessons l ON l.id = q.lesson_id
    JOIN public.modules m ON m.id = l.module_id
    JOIN public.courses c ON c.id = m.course_id
    JOIN public.enrollments e ON e.course_id = c.id
    WHERE quiz_questions.quiz_id = q.id AND e.student_id = auth.uid() AND c.status = 'published' AND l.published = true
  )
);

DROP POLICY IF EXISTS "quiz_questions_insert_teacher" ON public.quiz_questions;
CREATE POLICY "quiz_questions_insert_teacher"
ON public.quiz_questions FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "quiz_questions_update_teacher" ON public.quiz_questions;
CREATE POLICY "quiz_questions_update_teacher"
ON public.quiz_questions FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "quiz_questions_delete_teacher" ON public.quiz_questions;
CREATE POLICY "quiz_questions_delete_teacher"
ON public.quiz_questions FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── quiz_attempts ───
DROP POLICY IF EXISTS "quiz_attempts_select" ON public.quiz_attempts;
CREATE POLICY "quiz_attempts_select"
ON public.quiz_attempts FOR SELECT TO authenticated
USING (student_id = auth.uid() OR public.is_teacher());

DROP POLICY IF EXISTS "quiz_attempts_insert_student" ON public.quiz_attempts;
CREATE POLICY "quiz_attempts_insert_student"
ON public.quiz_attempts FOR INSERT TO authenticated
WITH CHECK (student_id = auth.uid());

-- ─── quiz_answers ───
DROP POLICY IF EXISTS "quiz_answers_select" ON public.quiz_answers;
CREATE POLICY "quiz_answers_select"
ON public.quiz_answers FOR SELECT TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.quiz_attempts a WHERE a.id = quiz_answers.attempt_id AND (a.student_id = auth.uid() OR public.is_teacher()))
);

DROP POLICY IF EXISTS "quiz_answers_insert_student" ON public.quiz_answers;
CREATE POLICY "quiz_answers_insert_student"
ON public.quiz_answers FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM public.quiz_attempts a WHERE a.id = quiz_answers.attempt_id AND a.student_id = auth.uid())
);

-- ─── classes ───
DROP POLICY IF EXISTS "classes_select" ON public.classes;
CREATE POLICY "classes_select"
ON public.classes FOR SELECT TO authenticated
USING (
  public.is_teacher()
  OR EXISTS (
    SELECT 1 FROM public.enrollments e
    WHERE e.course_id = classes.course_id AND e.student_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "classes_insert_teacher" ON public.classes;
CREATE POLICY "classes_insert_teacher"
ON public.classes FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "classes_update_teacher" ON public.classes;
CREATE POLICY "classes_update_teacher"
ON public.classes FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "classes_delete_teacher" ON public.classes;
CREATE POLICY "classes_delete_teacher"
ON public.classes FOR DELETE TO authenticated
USING (public.is_teacher());

-- ─── class_attendance ───
DROP POLICY IF EXISTS "class_attendance_select" ON public.class_attendance;
CREATE POLICY "class_attendance_select"
ON public.class_attendance FOR SELECT TO authenticated
USING (student_id = auth.uid() OR public.is_teacher());

DROP POLICY IF EXISTS "class_attendance_insert_teacher" ON public.class_attendance;
CREATE POLICY "class_attendance_insert_teacher"
ON public.class_attendance FOR INSERT TO authenticated
WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "class_attendance_update_teacher" ON public.class_attendance;
CREATE POLICY "class_attendance_update_teacher"
ON public.class_attendance FOR UPDATE TO authenticated
USING (public.is_teacher()) WITH CHECK (public.is_teacher());

DROP POLICY IF EXISTS "class_attendance_delete_teacher" ON public.class_attendance;
CREATE POLICY "class_attendance_delete_teacher"
ON public.class_attendance FOR DELETE TO authenticated
USING (public.is_teacher());
